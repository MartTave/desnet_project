#include "platform-config.h"
#include "trace/trace.h"
#include "board.h"

//using namespace board;

void board::initialize()
{
	Trace::initialize();
}

