var searchData=
[
  ['factory_0',['Factory',['../classapp_1_1Factory.html',1,'app']]],
  ['frame_1',['Frame',['../classdesenet_1_1Frame.html',1,'desenet']]]
];
