var searchData=
[
  ['windows_0',['Windows',['../architecture.html#windows',1,'']]],
  ['with_20ide_1',['Folders starting with IDE',['../index.html#ide_folders',1,'']]]
];
