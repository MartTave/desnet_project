var searchData=
[
  ['architecture_0',['DeSEm Architecture',['../architecture.html',1,'index']]],
  ['asked_20questions_1',['Frequently asked Questions',['../sec_faq.html',1,'index']]]
];
