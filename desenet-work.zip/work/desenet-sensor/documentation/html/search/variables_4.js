var searchData=
[
  ['footer_5fsize_0',['FOOTER_SIZE',['../classdesenet_1_1Frame.html#a62c6573e3d4f093713945b90d5952a68',1,'desenet::Frame']]]
];
