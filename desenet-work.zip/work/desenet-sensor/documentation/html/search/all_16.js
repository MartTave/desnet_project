var searchData=
[
  ['xf_0',['XF',['../architecture.html#xf',1,'']]]
];
