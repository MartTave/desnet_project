var searchData=
[
  ['receptioncallbackhandler_0',['ReceptionCallbackHandler',['../classdesenet_1_1NetworkInterfaceDriver.html#ab122371922d32d9f858829f161de5a3d',1,'desenet::NetworkInterfaceDriver']]]
];
