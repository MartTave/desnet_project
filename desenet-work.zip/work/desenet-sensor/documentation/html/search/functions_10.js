var searchData=
[
  ['randomaddress_0',['randomAddress',['../classphy_1_1Address.html#a7a51d35e39183c730aa78e5030fa40b9',1,'phy::Address']]],
  ['release_1',['release',['../classObjectPool.html#a1edc47ff7b7560c7e18b5efece95cf20',1,'ObjectPool']]],
  ['reservedlength_2',['reservedLength',['../classdesenet_1_1Frame.html#af84a00fc4695945c4b643d1c9b1bf898',1,'desenet::Frame']]],
  ['reset_3',['reset',['../classdesenet_1_1MultiPdu.html#aab50697a9a64ae73f797a01f4486fe4d',1,'desenet::MultiPdu']]],
  ['retain_4',['retain',['../classObjectPool.html#a96241c200f571416130badc9deaf9d3a',1,'ObjectPool']]]
];
