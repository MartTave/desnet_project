var searchData=
[
  ['data_0',['data',['../structdesenet_1_1mischief_1_1NetworkEntity_1_1EventElement.html#a095b8b416221c4d1ff975edbf24c5234',1,'desenet::mischief::NetworkEntity::EventElement::data'],['../structdesenet_1_1sensor_1_1NetworkEntity_1_1EventElement.html#af048ff3915b4c1da23cca160b45fce15',1,'desenet::sensor::NetworkEntity::EventElement::data']]]
];
