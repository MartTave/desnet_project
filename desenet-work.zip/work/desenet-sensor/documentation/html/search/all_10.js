var searchData=
[
  ['qt_20creator_0',['Qt Creator',['../devenv.html#qt_creator_ide',1,'']]],
  ['questions_1',['Questions',['../sec_faq.html',1,'Frequently asked Questions'],['../sec_faq.html#sec_faq',1,'Frequently asked Questions']]]
];
