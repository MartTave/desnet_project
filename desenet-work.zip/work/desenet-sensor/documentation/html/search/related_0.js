var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classdesenet_1_1Frame.html#afb1098e7df5c010dcf5a0b3ac727451b',1,'desenet::Frame']]]
];
