var searchData=
[
  ['ev_5fepdu_5fheader_5fsize_0',['EV_EPDU_HEADER_SIZE',['../classdesenet_1_1MultiPdu.html#a7787fe420c723a865f294b61caf3bc79',1,'desenet::MultiPdu']]]
];
