var searchData=
[
  ['descriptorlist_0',['DescriptorList',['../classdesenet_1_1NetworkInterfaceDriver.html#aab790233cce6767d45c664446afea3c6',1,'desenet::NetworkInterfaceDriver']]]
];
