var searchData=
[
  ['objectpool_0',['ObjectPool',['../classObjectPool.html',1,'']]],
  ['observer_1',['Observer',['../classdesenet_1_1gateway_1_1NetworkEntity_1_1Observer.html',1,'desenet::gateway::NetworkEntity::Observer'],['../classITimeSlotManager_1_1Observer.html',1,'ITimeSlotManager::Observer']]]
];
