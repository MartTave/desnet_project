var searchData=
[
  ['header_5fsize_0',['HEADER_SIZE',['../classdesenet_1_1Frame.html#a94aa51569dd3f26cd2c0ea23c32fd220',1,'desenet::Frame']]]
];
