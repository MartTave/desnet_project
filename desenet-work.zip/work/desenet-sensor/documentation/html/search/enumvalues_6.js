var searchData=
[
  ['tm_5fbeacon_5fsend_5finterval_5fid_0',['TM_BEACON_SEND_INTERVAL_id',['../classdesenet_1_1gateway_1_1NetworkEntity.html#ab4fb054789913edea4aff8f200bf2afda01c871806b2e2934cf66cfd6f92f8605',1,'desenet::gateway::NetworkEntity']]]
];
