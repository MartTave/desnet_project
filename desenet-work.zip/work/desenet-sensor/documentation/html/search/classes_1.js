var searchData=
[
  ['beacon_0',['Beacon',['../classdesenet_1_1Beacon.html',1,'desenet']]]
];
