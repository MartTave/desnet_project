var searchData=
[
  ['size_0',['SIZE',['../classdesenet_1_1Beacon.html#a114135c402bf65fc4935507672350876',1,'desenet::Beacon']]],
  ['sv_5fepdu_5fheader_5fsize_1',['SV_EPDU_HEADER_SIZE',['../classdesenet_1_1MultiPdu.html#ad934c484417d0b4eadc0c38997e62ac6',1,'desenet::MultiPdu']]]
];
